/**
 * @file    storage_config.c
 * @brief   存储分区配置表实例
 */

#include "storage_config.h"
#include <string.h>

/* ============================================================
 * 分区配置表
 * ============================================================ */
const storage_config_t g_storage_configs[] = {
    {
        .name        = "sys_param",
        .sector_addr = FLASH_ADDR_SYS_PARAM,
        .sector_size = FLASH_PARAM_SECTOR_SIZE,
        .magic       = 0x53595350,   /* "SYSP" */
        .cooldown_ms = 500,
    },
    {
        .name        = "device_info",
        .sector_addr = FLASH_ADDR_DEVICE_INFO,
        .sector_size = FLASH_PARAM_SECTOR_SIZE,
        .magic       = 0x44455649,   /* "DEVI" */
        .cooldown_ms = 1000,
    },
    {
        .name        = "ota_shared",
        .sector_addr = FLASH_ADDR_OTA_SHARED,
        .sector_size = FLASH_PARAM_SECTOR_SIZE,
        .magic       = 0x4F5441,     /* "OTA" */
        .cooldown_ms = 100,
    },
    {
        .name        = "mode_config",
        .sector_addr = FLASH_ADDR_MODE_CONFIG,
        .sector_size = FLASH_PARAM_SECTOR_SIZE,
        .magic       = 0x4D4F4445,   /* "MODE" */
        .cooldown_ms = 1000,
    },
};

const uint32_t g_storage_config_count = sizeof(g_storage_configs) / sizeof(g_storage_configs[0]);

/* ============================================================
 * 查找配置
 * ============================================================ */
const storage_config_t* storage_find_config(const char *name)
{
    if (name == NULL) return NULL;

    for (uint32_t i = 0; i < g_storage_config_count; i++) {
        if (strcmp(g_storage_configs[i].name, name) == 0) {
            return &g_storage_configs[i];
        }
    }
    return NULL;
}
