/**
 * @file    app_main.c
 * @brief   前台主线程：事件驱动，处理核心业务
 */

#include <rtthread.h>
#include "app_event.h"
#include "ipc_center.h"
#include "state_engine.h"

#include "pitch/pitch_angle.h"
#include "pitch/pitch_control.h"
#include "pitch/pitch_actions.h"
#include "pitch/pitch_sensor.h"

#include "hori/hori_angle.h"
#include "hori/hori_control.h"

#include "hori/hori_actions.h"
#include "mode/mode_control.h"
#include "mode/mode_actions.h"

/* CAN 状态上报发送帧缓存（事件驱动数据源） */
#include "CAN/status_tx.h"
#include "CAN/led_tx.h"
#include "CAN/ut_can_handlers.h"

/* 启车状态判定 */
#include "service/vehicle_state.h"

#include "sm_assert.h"

/* ============================================================
 * 启车门禁判定
 * ============================================================
 * 依据 SRS：
 *   REQ003/004/005/006（手动左/右/上/下）→ 前置条件仅为「车辆上电」
 *   REQ007/008/009（一键右中/右后/回位）→ 前置条件为「车辆处于启车状态」
 *   REQ011/012（离合结合/分离）        → 前置条件为「车辆处于启车状态」
 *
 * 因此只能按事件枚举精确拦截，不能按区间：
 *   HORI_EVT_ONKEY_* 与 HORI_EVT_LEFT/RIGHT_* 同在 0x2000 区间。
 * ============================================================ */
static uint8_t evt_needs_vehicle_started(app_event_t e)
{
    switch (e) {
    case HORI_EVT_ONKEY_MIDDLE:
    case HORI_EVT_ONKEY_REAR:
    case HORI_EVT_ONKEY_HOME:
        return 1U;

    case SEQ_EVT_ONKEY_MIDDLE:
    case SEQ_EVT_ONKEY_REAR:
    case SEQ_EVT_ONKEY_HOME:
        return 1U;

    case CLUTCH_EVT_COMBINE:
    case CLUTCH_EVT_SEPARATE:
        return 1U;

    default:
        return 0U;      /* 手动上下/左右：只需上电，放行 */
    }
}

/* 外部俯仰角对象 */
extern pitch_angle_t g_pitch_angle;
//extern StateMachine_t g_pitch_sm;

/**
 * @brief 前台主线程入口
 */
void app_main_thread_entry(void *param)
{
    app_event_t event;

    rt_kprintf("[app_main] Started, waiting for events...\n\n");

    while (1) {
        /* 阻塞等待事件（无事件时挂起） */
        rt_mq_recv(g_app_event_mq, &event, sizeof(app_event_t), RT_WAITING_FOREVER);

        /* ----- 50ms Tick 处理 ----- */
        if (event == EVT_TICK_50MS) {
            /* 更新俯仰角对象：读取电压 → 计算角度 → 检测位置变化 → 投递事件 */
            pitch_angle_update(&g_pitch_angle);

            /* 更新 水平角对象：spi获取3颗编码器信息 → 计算角度 → 检测位置变化 → 投递事件 */
            hori_angle_update(&g_hori_angle);

            /* 2. 刹车到位上报
                                       *    必须显式调用：StateFuncTable_t 只有 state/enter/exit 三个字段
                                       *    （state_engine.h:46-50），没有 tick 回调入口 */
            hori_act_tick_check(&g_hori_obj.ctx);
            pitch_act_tick_check(&g_pitch_obj.ctx);
            /* 3. 模式超时检测（同样无法挂进函数表） */
            mode_tick_check(&g_mode_obj.ctx);

            /* 4. 角度已刷新 → 通知 0x18FF11D1 状态帧更新缓存 */
            post_event(CAN_EVT_STA_ANGLE);

            /* 5. 角度传感器故障 → 俯仰控制上下文
             *    感知层不依赖业务层，由调度层在此搬运 */
            if (g_pitch_angle.sensor != RT_NULL) {
                pitch_control_update_sensor_fault(
                    pitch_sensor_get_fault(g_pitch_angle.sensor));
            }

            /* 6. 启车状态判定：50ms 轮询 + 迟滞 */
            vehicle_poll();

            /* 阀故障 500ms 去抖 */
//            pitch_control_valve_fb_poll();

//            if (++s_tick_div >= 4U) {             /* 200ms 状态帧 */
//                s_tick_div = 0U;
//                valve_tx_apply();
//            }
            continue;   /* tick 不投给状态机：自转移在 state_engine.c:106 直接 return，投了也是空转 */


            /* 序列引擎周期更新 */
//            extern void seq_control_tick_update(void);   /* 或直接调用 */
//            seq_control_update();   /* 需将函数暴露 */
            /* 可在此添加其他 50ms 周期任务 */
        }

        /* ----- 系统事件：启车 / 熄车状态跳变 ----- */
        if (event == SYS_EVT_VEHICLE_STARTED) {
            rt_kprintf("[app_main] vehicle STARTED -> output enabled\n");
            post_event(CAN_EVT_LED_IND);        /* 通知灯帧刷新 */
            continue;
        }
        if (event == SYS_EVT_VEHICLE_STOPPED) {
            rt_kprintf("[app_main] vehicle STOPPED -> output disabled\n");
            post_event(CAN_EVT_LED_IND);
            continue;
        }

        /* ----- 系统事件：机型设置被清除（Q4 可配置行为） ----- */
        if (event == SYS_EVT_TEETH_CLEARED) {
            /* 由 sys_param.teeth_clear_action 触发（TEETH_CLEAR_STOP）
             * TODO(Q4)：按业务需要停止输出
             *   post_event(HORI_EVT_SEQ_ABORT);
             *   post_event(PITCH_EVT_SEQ_STOP);
             *   或调用对应模块 stop 接口 */
            rt_kprintf("[app_main] teeth cleared -> stop output\n");
            continue;
        }

        /* ----- CAN 状态上报事件（0x4010 ~ 0x402F）-----
         * 只刷新本机发送帧的本地缓存，实际发帧由 can_tx 周期调度。
         * 区间与 app_event.h can_event_t 定义保持一致。
         */
        if (event >= (CAN_EVENT_BASE + 0x10) && event <= (CAN_EVENT_BASE + 0x2F)) {
            status_tx_on_event(event);
            led_tx_on_event(event);
            continue;
        }

        /* ----- 启车门禁：一键/离合需启车状态，手动四向放行（SRS） ----- */
        if ((vehicle_is_started() == 0U) &&
            (evt_needs_vehicle_started(event) != 0U)) {
            rt_kprintf("[app_main] drop evt 0x%X: vehicle not started\n",
                       (unsigned)event);
            continue;
        }

        /* ----- 转发到各业务状态机 ----- */
        if (event >= PITCH_EVENT_BASE && event < HORI_EVENT_BASE) {
            /* 俯仰 0x1000 ~ 0x1FFF */
            StateMachine_SendEvent(&g_pitch_obj.sm_instance, event);
        } else if (event >= HORI_EVENT_BASE && event < CALIB_EVENT_BASE) {
            /* 水平 0x2000 ~ 0x2FFF（原先遗漏，导致左右手动完全不动） */
            StateMachine_SendEvent(&g_hori_obj.sm_instance, event);
        }
        /* 校准 0x3000：待校准模块（独立）接入后转发 */

    }
}
