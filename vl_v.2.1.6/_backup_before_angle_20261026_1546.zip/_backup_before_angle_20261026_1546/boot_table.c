/**
 * @file    boot_table.c
 * @brief   应用层启动序列表实例 —— 唯一维护点
 * @note    表顺序 = 执行顺序；level 仅用于一致性校验；
 *          retry_max 仅 BOOT_RETRY 有效
 */

#include "boot_table.h"
#include <rtthread.h>
#include "../framework/manager/ctrl_manager.h"
#include "../tick/tick_50ms.h"
#include "../bsp/bsp_hw_init.h"


/* ===================== 外部入口声明 ===================== */
extern int  ipc_center_init(void);
extern int  storage_all_init(void);
extern int  bg_scheduler_init(void);
extern int  app_hw_init(void);
extern int  motor_module_init(void);
extern int  mode_init(void);
extern int  pitch_init(void);
extern int  hori_init(void);
extern int  seq_init(void);
extern int  can_init(void);
extern int  can_tx_init(void);
extern int  status_tx_init(void);
extern int  led_tx_init(void);
extern int  sys_voltage_init(void);
extern int  vehicle_state_init(void);
extern int  eeprom_init(void);
extern int  kb_init(void);
extern int  wdt_monitor_init(void);

extern void app_main_thread_entry(void *param);
extern void bg_scheduler_thread_entry(void *param);

extern ctrl_manager_t g_ctrl_mgr;

/* ===================== 适配层：包成 (void) 形式 ===================== */
static int boot_ctrl_mgr_init(void)  { return (int)ctrl_manager_init(&g_ctrl_mgr); }
static int boot_ctrl_mgr_start(void) { return (int)ctrl_manager_start(&g_ctrl_mgr); }

/* ===================== 硬件初始化校验 ===================== */
/**
 * @brief  校验 MCU 硬件资源初始化结果
 * @note   MCU 资源由 INIT_DEVICE_EXPORT(bsp_hw_init) 在 main() 之前完成，
 *         此处只读 g_hw_init_error_map，不重复初始化硬件。
 *         这是「硬件表」与「对象表」之间唯一的衔接点。
 */
static int boot_hw_check(void)
{
    if (g_hw_init_error_map != 0U) {
        rt_kprintf("[BOOT] hw init error map = 0x%08X\n",
                   (unsigned int)g_hw_init_error_map);
        return -1;
    }
    rt_kprintf("[BOOT] hw_check pass\n");
    return 0;
}

/* ===================== 线程创建 ===================== */
static int boot_create_threads(void)
{
    rt_thread_t tid;

    /* ============================================================
     * Phase 4: 创建前台主线程 (app_main)
     * 优先级 6，栈大小 4096，事件驱动
     * ============================================================ */
    tid = rt_thread_create("app_main", app_main_thread_entry, RT_NULL, 4096, 6, 10);
    if (tid == RT_NULL) return -1;
    rt_thread_startup(tid);

    /* ============================================================
     * Phase 5: 创建后台调度线程 (bg_sched)
     * 优先级 15，栈大小 1024，时间轮询
     * ============================================================ */
    tid = rt_thread_create("bg_sched", bg_scheduler_thread_entry, RT_NULL, 1536, 15, 10);
    if (tid == RT_NULL) return -1;
    rt_thread_startup(tid);

    return 0;
}

/* ===================== 启动表 ===================== */
const boot_step_t g_boot_steps[] = {
    /*  name              fn                    level               policy         retry  deps */
    {"hw_check",         boot_hw_check,        BOOT_LV_EARLY,      BOOT_FATAL,    0, {NULL}},
    {"ipc_center",       ipc_center_init,      BOOT_LV_IPC,        BOOT_FATAL,    0, {NULL}},
    {"storage",          storage_all_init,     BOOT_LV_STORAGE,    BOOT_FATAL,    0, {"ipc_center"}},
    {"ctrl_mgr_init",    boot_ctrl_mgr_init,   BOOT_LV_FRAMEWORK,  BOOT_FATAL,    0, {NULL}},
    {"app_hw",           app_hw_init,          BOOT_LV_HW,         BOOT_FATAL,    0, {"storage"}},
    {"motor",            motor_module_init,    BOOT_LV_HW,         BOOT_FATAL,    0, {"app_hw"}},
    {"mode",             mode_init,            BOOT_LV_APP,        BOOT_FATAL,    0, {"ctrl_mgr_init"}},
    {"pitch",            pitch_init,           BOOT_LV_APP,        BOOT_FATAL,    0, {"storage", "ctrl_mgr_init"}},
    {"hori",             hori_init,            BOOT_LV_APP,        BOOT_FATAL,    0, {"app_hw", "ctrl_mgr_init"}},
    {"seq",              seq_init,             BOOT_LV_APP,        BOOT_FATAL,    0, {"ctrl_mgr_init"}},
    {"ctrl_mgr_start",   boot_ctrl_mgr_start,  BOOT_LV_START,      BOOT_FATAL,    0, {"ctrl_mgr_init"}},
    {"bg_sched_init",    bg_scheduler_init,    BOOT_LV_SERVICE,    BOOT_FATAL,    0, {NULL}},
    {"sys_voltage",      sys_voltage_init,     BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"storage"}},
    {"eeprom",           eeprom_init,          BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"storage"}},
    {"keyboard",         kb_init,              BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"seq", "ipc_center"}},
    {"vehicle",          vehicle_state_init,   BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"sys_voltage"}},
    {"can",              can_init,             BOOT_LV_SERVICE,    BOOT_RETRY,    3, {"ipc_center"}},
    {"can_tx",           can_tx_init,          BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"can"}},
    {"status_tx",        status_tx_init,       BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"can_tx"}},
    {"led_tx",           led_tx_init,          BOOT_LV_SERVICE,    BOOT_FATAL,    0, {"can_tx"}},
    {"threads",          boot_create_threads,  BOOT_LV_THREAD,     BOOT_FATAL,    0, {"ipc_center"}},
    {"tick_50ms",        tick_50ms_init,       BOOT_LV_THREAD,     BOOT_FATAL,    0, {"threads"}},
    {"wdt",              wdt_monitor_init,     BOOT_LV_WDT,        BOOT_FATAL,    0, {"threads"}},
};

const uint16_t g_boot_step_count = sizeof(g_boot_steps) / sizeof(g_boot_steps[0]);
