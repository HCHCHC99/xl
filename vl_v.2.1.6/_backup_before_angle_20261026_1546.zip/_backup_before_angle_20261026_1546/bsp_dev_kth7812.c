/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-01-29     gylocal       the first version
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <rtdef.h>
#include <rthw.h>

#include "bsp_dev_kth7812.h"
#include "bsp_drv_spi.h"

#include "hc32_ll_spi.h"

#define HCLK_VALUE                      (SystemCoreClock >> ((CM_CMU->SCFGR & CMU_SCFGR_HCLKS) >> CMU_SCFGR_HCLKS_POS))
#define BSP_SPI_TIMEOUT                 (HCLK_VALUE)

KTH7812_CONFIG_DEF kth7812_config_data[KTH7812_DEV_MAX]={
        [KTH7812_DEV_41]  = {
                .cs_pin = {
                        .pin = GET_PIN(A,9)  ,
                        .mode =  PIN_MODE_OUTPUT_OD,
                        .status = PIN_HIGH
                },
                .spi_device = NULL,
                .kth7812_op_data = {
                        .kth7812_op_cmd = 0
                }
        },
        [KTH7812_DEV_42]  = {
                .cs_pin = {
                        .pin = GET_PIN(A,8)  ,
                        .mode =  PIN_MODE_OUTPUT_OD,
                        .status = PIN_HIGH
                },
                .spi_device = NULL,
                .kth7812_op_data = {
                        .kth7812_op_cmd = 0
                }
        },
        [KTH7812_DEV_43]  = {
                .cs_pin = {
                        .pin = GET_PIN(A,15)  ,
                        .mode =  PIN_MODE_OUTPUT_OD,
                        .status = PIN_HIGH
                },
                .spi_device = NULL,
                .kth7812_op_data = {
                        .kth7812_op_cmd = 0
                }
        }
};


typedef struct{
    union{
        uint16_t cmd;
        struct{
            uint16_t cmd_type : 2;
            uint16_t cmd_addr : 6;
            uint16_t cmd_data : 8;
        };
    };
}KTH7812_CMD_DEF;

//rt_spi_send_then_recv(spi_dev_HCT6961, &TxData, 6, &Rxdata, 0);


uint32_t spruce_crc4(uint8_t *data,uint32_t len ); //CRC4校验计算


//extern rt_err_t rt_spi_send_then_recv(struct rt_spi_device *device,
//                               const void           *send_buf,
//                               rt_size_t             send_length,
//                               void                 *recv_buf,
//                               rt_size_t             recv_length);

static void kth7812_hardware_init(void)
{
//    KTH7812_DEV_DEF count = KTH7812_DEV_41;
//    for (; count < KTH7812_DEV_MAX; ++count) {
//
//        rt_pin_mode(kth7812_config_data[count].cs_pin.pin,
//                    kth7812_config_data[count].cs_pin.mode);
//
//        rt_pin_write(kth7812_config_data[count].cs_pin.pin,
//                    kth7812_config_data[count].cs_pin.status);
//    }

}



/**
  * @brief  CRC4 Table
  */
static uint8_t CRC4TableFor0x03[] =
{
  0x00, 0x03, 0x06, 0x05, 0x0C, 0x0F, 0x0A, 0x09,
  0x0B, 0x08, 0x0D, 0x0E, 0x07, 0x04, 0x01, 0x02,
  0x05, 0x06, 0x03, 0x00, 0x09, 0x0A, 0x0F, 0x0C,
  0x0E, 0x0D, 0x08, 0x0B, 0x02, 0x01, 0x04, 0x07,
  0x0A, 0x09, 0x0C, 0x0F, 0x06, 0x05, 0x00, 0x03,
  0x01, 0x02, 0x07, 0x04, 0x0D, 0x0E, 0x0B, 0x08,
  0x0F, 0x0C, 0x09, 0x0A, 0x03, 0x00, 0x05, 0x06,
  0x04, 0x07, 0x02, 0x01, 0x08, 0x0B, 0x0E, 0x0D,
  0x07, 0x04, 0x01, 0x02, 0x0B, 0x08, 0x0D, 0x0E,
  0x0C, 0x0F, 0x0A, 0x09, 0x00, 0x03, 0x06, 0x05,
  0x02, 0x01, 0x04, 0x07, 0x0E, 0x0D, 0x08, 0x0B,
  0x09, 0x0A, 0x0F, 0x0C, 0x05, 0x06, 0x03, 0x00,
  0x0D, 0x0E, 0x0B, 0x08, 0x01, 0x02, 0x07, 0x04,
  0x06, 0x05, 0x00, 0x03, 0x0A, 0x09, 0x0C, 0x0F,
  0x08, 0x0B, 0x0E, 0x0D, 0x04, 0x07, 0x02, 0x01,
  0x03, 0x00, 0x05, 0x06, 0x0F, 0x0C, 0x09, 0x0A,
  0x0E, 0x0D, 0x08, 0x0B, 0x02, 0x01, 0x04, 0x07,
  0x05, 0x06, 0x03, 0x00, 0x09, 0x0A, 0x0F, 0x0C,
  0x0B, 0x08, 0x0D, 0x0E, 0x07, 0x04, 0x01, 0x02,
  0x00, 0x03, 0x06, 0x05, 0x0C, 0x0F, 0x0A, 0x09,
  0x04, 0x07, 0x02, 0x01, 0x08, 0x0B, 0x0E, 0x0D,
  0x0F, 0x0C, 0x09, 0x0A, 0x03, 0x00, 0x05, 0x06,
  0x01, 0x02, 0x07, 0x04, 0x0D, 0x0E, 0x0B, 0x08,
  0x0A, 0x09, 0x0C, 0x0F, 0x06, 0x05, 0x00, 0x03,
  0x09, 0x0A, 0x0F, 0x0C, 0x05, 0x06, 0x03, 0x00,
  0x02, 0x01, 0x04, 0x07, 0x0E, 0x0D, 0x08, 0x0B,
  0x0C, 0x0F, 0x0A, 0x09, 0x00, 0x03, 0x06, 0x05,
  0x07, 0x04, 0x01, 0x02, 0x0B, 0x08, 0x0D, 0x0E,
  0x03, 0x00, 0x05, 0x06, 0x0F, 0x0C, 0x09, 0x0A,
  0x08, 0x0B, 0x0E, 0x0D, 0x04, 0x07, 0x02, 0x01,
  0x06, 0x05, 0x00, 0x03, 0x0A, 0x09, 0x0C, 0x0F,
  0x0D, 0x0E, 0x0B, 0x08, 0x01, 0x02, 0x07, 0x04,
};

/**
  * @brief  Reverses 8 bits of data.
  * @param  8 bits of data.
  * @retval The result after 8 bits of data is reversed
  */
static uint8_t ByteReverse(uint8_t data)
{
  uint8_t temp = 0;

  for (int i = 0; i < 4; i++)
  {
    temp |= (uint8_t)(   ((data >> i) & 0x01) << (7 - i)   );
  }

  return temp;
}

/**
  * @brief  Checks the angle by CRC4.
  * @param  Angle buffer.
  * @param  Angle buffer length.
  * @retval CRC4
  */
static uint8_t CalCRC4(uint8_t *puchMsg, uint32_t dataLen)
{
  uint8_t crc = 0x00;
  uint8_t datatemp = 0x00;

  for (uint32_t i = 0; i < dataLen; i++)
  {
    datatemp = ByteReverse(puchMsg[i]);
    crc = (uint8_t)(CRC4TableFor0x03[crc ^ datatemp] << 4);
  }

  crc = ByteReverse(crc);
  return crc;

//    const uint8_t poly = 0x03;
//        uint8_t crc = 0x00;
//
//        while (dataLen--)
//        {
//            uint8_t byte = *puchMsg++;
//            // 输入反转（RefIn=True）
//            byte = ((byte & 0x01) << 7) | ((byte & 0x02) << 5) |
//                   ((byte & 0x04) << 3) | ((byte & 0x08) << 1) |
//                   ((byte & 0x10) >> 1) | ((byte & 0x20) >> 3) |
//                   ((byte & 0x40) >> 5) | ((byte & 0x80) >> 7);
//
//            crc ^= byte;
//            for (int i = 0; i < 8; i++)
//            {
//                if (crc & 0x80)
//                    crc = (crc << 1) ^ (poly << 4);
//                else
//                    crc <<= 1;
//            }
//        }
//
//        // 输出反转（RefOut=True）
//        crc = ((crc & 0x08) >> 3) | ((crc & 0x04) >> 1) |
//              ((crc & 0x02) << 1) | ((crc & 0x01) << 3);
//        // XorOut=0x00，无需处理
//        return crc & 0x0F;


}

/**
 * @brief  SPI 全双工收发 16-bit (同时发送和接收, 恰好 16 个时钟)
 */
static uint16_t KTH78_SpiXfer16(uint8_t txH, uint8_t txL)
{
    uint8_t txBuf[2] = {txH, txL};
    uint8_t rxBuf[2] = {0, 0};

    SPI_TransReceive(CM_SPI1, txBuf, rxBuf, 2, BSP_SPI_TIMEOUT);

    return ((uint16_t)rxBuf[0] << 8) | rxBuf[1];
}


/**
 * @brief  获取设备对应的 CS 端口和引脚
 */
static void KTH78_GetCS(KTH7812_DEV_DEF index, uint8_t *port, uint16_t *pin)
{
    switch (index) {
        case KTH7812_DEV_41: *port = GPIO_PORT_A; *pin = GPIO_PIN_09; break;
        case KTH7812_DEV_42: *port = GPIO_PORT_A; *pin = GPIO_PIN_08; break;
        case KTH7812_DEV_43: *port = GPIO_PORT_A; *pin = GPIO_PIN_15; break;
        default:             *port = GPIO_PORT_A; *pin = GPIO_PIN_09; break;
    }
}

/**
 * @brief  写入 KTH7801 寄存器 (datasheet 5.3节)
 * @param  regAddr: 寄存器地址 (0x00~0x09)
 * @param  value: 写入值 (8-bit)
 * @param  index: 设备编号
 *
 * 帧格式: [10][addr6][value8]
 * 注意: 写入后需等待 20ms, MTP仅支持1000次写入!
 */
void KTH78_WriteReg(uint8_t regAddr, uint8_t value, KTH7812_DEV_DEF index)
{
    uint8_t cs_port;
    uint16_t cs_pin;
    uint8_t txBuf[2];

    KTH78_GetCS(index, &cs_port, &cs_pin);

    /* 写命令: bit[15:14]=10, bit[13:8]=regAddr, bit[7:0]=value */
    txBuf[0] = 0x80 | (regAddr & 0x3F);
    txBuf[1] = value;

    GPIO_ResetPins(cs_port, cs_pin);
    DDL_DelayUS(1);
    SPI_Trans(CM_SPI1, txBuf, 2, BSP_SPI_TIMEOUT);
    DDL_DelayUS(1);
    GPIO_SetPins(cs_port, cs_pin);

    /* datasheet: 写入后等待至少 20ms */
    DDL_DelayMS(25);
}

/**
  * @brief  Reads the register value via the address parameter.
  * @param  Register address.
  * @retval Register value
  */
uint8_t KTH78_ReadReg(struct rt_spi_device *device, uint8_t regAddr , KTH7812_DEV_DEF index )
{
    uint8_t cs_port;
    uint16_t cs_pin;
    uint16_t resp;

    KTH78_GetCS(index, &cs_port, &cs_pin);

    /* 帧1: 发送读命令, 不关心返回 */
    uint8_t cmdH = 0x40 | (regAddr & 0x3F);
    GPIO_ResetPins(cs_port, cs_pin);
    DDL_DelayUS(1);
    KTH78_SpiXfer16(cmdH, 0x00);
    DDL_DelayUS(1);
    GPIO_SetPins(cs_port, cs_pin);
    DDL_DelayUS(1);  /* Tpause > 150ns */

    /* 帧2: 发送空命令, 同时接收上一帧的响应 */
    GPIO_ResetPins(cs_port, cs_pin);
    DDL_DelayUS(1);
    resp = KTH78_SpiXfer16(0x00, 0x00);
    DDL_DelayUS(1);
    GPIO_SetPins(cs_port, cs_pin);

    /* 响应格式: 高8位=寄存器值, 低8位=0x00 */
    return (uint8_t)(resp >> 8);
}






/**
 * @brief  读取 KTH7801 绝对角度 (datasheet 5.4节)
 * @param  index: 设备编号
 * @retval 16-bit 原始角度值 (非CRC版: 0~65535, CRC版: 高12位角度+低4位CRC)
 *
 * 读角度命令: opcode = 000, MOSI 保持 0x00
 * 一个 CS 周期内 16 个 SCLK, MISO 同时返回角度数据
 */
uint16_t KTH78_ReadAngle(KTH7812_DEV_DEF index)
{
    uint8_t cs_port;
    uint16_t cs_pin;

    KTH78_GetCS(index, &cs_port, &cs_pin);

    /* CS 拉低 */
    GPIO_ResetPins(cs_port, cs_pin);
    DDL_DelayUS(1);

    /* 全双工收发: MOSI 发 0x0000 (opcode=000), MISO 返回角度 */
    uint16_t raw = KTH78_SpiXfer16(0x00, 0x00);

    DDL_DelayUS(1);
    /* CS 拉高, Tpause > 150ns */
    GPIO_SetPins(cs_port, cs_pin);

    return raw;
}
/**
  * @brief  Reads the angle and returns the result.
  * @note   The default configuration is 12bit angle + 4bit CRC4.
            If the CRC check succeeds, an angle of 12 bits is returned.
            If the CRC check fails, the data is invalid and 0xFFFF is returned.
  * @retval Angle or 0xFFFF
  */
//uint16_t KTH78_ReadAngle(struct rt_spi_device *device, KTH7812_DEV_DEF index )
//{
//    uint16_t angle=0;
//
//    typedef union{
//        uint16_t data_received;
//
//        struct{
//            uint16_t data_back_1 : 8 ;
//            uint16_t data_back_0 : 8 ;
//        }byte_part;
//
//        struct{
//            uint16_t data_crc   : 4  ;
//            uint16_t data_angle : 12 ;
//        }func_part;
//    }KTH7812_DATA_DEF;
//    KTH7812_DATA_DEF kth7812_data={0};
//
//    uint16_t data = 0;
//    uint8_t dataSend[2] = {0, 0};
//
//#include "hc32_ll_spi.h"
//#define HCLK_VALUE                      (SystemCoreClock >> ((CM_CMU->SCFGR & CMU_SCFGR_HCLKS) >> CMU_SCFGR_HCLKS_POS))
//#define BSP_SPI_TIMEOUT                 (HCLK_VALUE)
//
//#include "hc32_ll_gpio.h"
//
//    switch (index) {
//        case KTH7812_DEV_41:
//
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_09);
//            rt_hw_us_delay(2);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(2);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_09);               // 芯片数据返回，需要再次下拉
//            rt_hw_us_delay(2);
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_09);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(10);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_09);
//            break;
//
//        case KTH7812_DEV_42:
//
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_08);
//            rt_hw_us_delay(2);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(2);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_08);               // 芯片数据返回，需要再次下拉
//            rt_hw_us_delay(2);
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_08);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(10);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_08);
//            break;
//
//        case KTH7812_DEV_43:
//
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_15);
//            rt_hw_us_delay(2);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(2);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_15);               // 芯片数据返回，需要再次下拉
//            rt_hw_us_delay(2);
//            GPIO_ResetPins(GPIO_PORT_A , GPIO_PIN_15);
//
//            SPI_TransReceive(CM_SPI1,dataSend,&kth7812_data.data_received,2,BSP_SPI_TIMEOUT);
//
//            rt_hw_us_delay(10);
//            GPIO_SetPins(GPIO_PORT_A , GPIO_PIN_15);
//            break;
//        default:
//            break;
//    }
//
////    data = (uint16_t)(dataBack[0] << 8) | dataBack[1];
////
////    uint8_t temp[] = {data >> 12 , data >> 4};
//
//    // 校验数据
//    uint8_t crc4 = CalCRC4( (uint8_t *)&kth7812_data.data_received, 2);
//
////    if (crc4 != (kth7812_data.func_part.data_crc) )
////    {
////        data = 0xFFFF;
////    }
////    else
////    {
////        data >>= 4;
////    }
//
////    // 角度放大 100倍
////    kth7812_data.func_part.data_angle = kth7812_data.func_part.data_angle ;
//
//    return kth7812_data.func_part.data_angle;
//}

void kth7812_SpiWriteCmd( struct rt_spi_device *device , KTH7812_OP_CMD *cmd )//（不带校验）写操作
{
    uint8_t TxData[10]={0};
    uint8_t Rxdata[10]={0};

    rt_memcpy(TxData, cmd, sizeof(cmd) );

    rt_spi_send_then_recv(device, TxData, 2, Rxdata, 0);
}

void kth7812_SpiWriteCmdCheck(struct rt_spi_device *device , KTH7812_OP_CMD *cmd)//（带校验）写操作
{
    // 待 确认芯片写入，是否需要CRC


//    uint8_t TxData[10]={0};
//    uint8_t Rxdata[10]={0};
//
//    rt_memcpy(TxData, cmd, sizeof(cmd) );
//
//    rt_spi_send_then_recv(device, TxData, 2, Rxdata, 0);
}


uint32_t kth7812_SpiReadCmdCheck(struct rt_spi_device *device , KTH7812_OP_CMD *cmd)//（带校验）读操作
{

    uint32_t read_data;

    return read_data;
}


//SPIx 读写一个字节
//TxData:要写入的字节
//返回值:读取到的字节
uint8_t kth7812_ReadWriteByte(uint8_t TxData)
{
    uint8_t Rxdata=0;
////    rt_spi_send_then_recv(spi_dev_HCT6961, &TxData, 1, &Rxdata, 1);
//
//    HAL_SPI_TransmitReceive( &hspi1, &TxData, &Rxdata, 1, 1000);


    return Rxdata;
}

uint32_t spruce_crc4(uint8_t *data,uint32_t len ) //CRC4校验计算
{
    uint8_t i,j;

    const uint8_t POLYNOMIAL_LOW4 = 0x03;  // 生成多项式低 4 位（0011），实际参与异或运算
    uint8_t crc4 = 0x00;                   // 初始化余数（4 位，对应 0000）

    for (i=0;i<len;i++)
    {
        uint8_t current_byte = data[i];   // 取出当前待处理字节
        for (j=0;j<8;j++)
        {
            // 提取当前比特位（从最高位到最低位，即 bit7 ~ bit0）
            uint8_t current_bit = (current_byte >> 7) & 0x01;
            // 提取当前 CRC 余数的最高位（4 位 CRC 的第 3 位，对应二进制左数第 1 位）
            uint8_t crc_high_bit = (crc4 >> 3) & 0x01;

            // 4. 模 2 除法：左移 CRC 余数，并入当前比特位（保留低 4 位，防止溢出）
            crc4 = (crc4 << 1) & 0x0F;
            crc4 |= current_bit;

            // 5. 若最高位为 1，与生成多项式低 4 位进行异或运算
            if ((crc_high_bit ^ current_bit) != 0)
            {
                crc4 ^= POLYNOMIAL_LOW4;
            }

            // 6. 当前字节左移 1 位，准备处理下一个比特位
            current_byte = (current_byte << 1) & 0xFF;
        }
    }
    return crc4;
}


void dev_kth7812_init(void){
    rt_kprintf("dev_kth7812_init!\n\n");
    kth7812_hardware_init();
}


